
Thanks for downloading the SlopeAngleMaps.com Sample overlay!


Step 1:
Extract the .zip folder to somewhere on your computer (overlays won't load from .zip folders).
You can place the extracted files anywhere on your computer you would like. All you have to do 
is keep the the .kml and two image files in the same directory for the overlay to work.


Step 2:
To open the overlay, just double-click the .kml file

 - OR - 

Open Google Earth, then File->Open and find your .kml file.



TIP:
Don't forget to play with the layer transparency in Google Earth for maximum usability!



Order a custom overlay for any region you would like!
More information at SlopeAngleMaps.com

Thanks for your interest!